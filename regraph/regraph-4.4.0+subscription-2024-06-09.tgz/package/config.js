/**
 * ReGraph 4.4.0
 * Licensed to Centre for Strategic Infocomm Technologies for Network Mapping Application expires 09 June 2024
 * 
 * Copyright © 2011-2024 Cambridge Intelligence Limited.
 * All rights reserved.
 */"use strict";Object.defineProperty(exports,"__esModule",{value:!0});const e=require("regraph/core")._setCorsAdapter;exports.setCorsAdapter=e;
