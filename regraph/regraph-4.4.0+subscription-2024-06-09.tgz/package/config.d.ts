 /**
 * Type definitions for ReGraph config functions.
 * 
 * Copyright © 2011-2023 Cambridge Intelligence Limited.
 * All rights reserved.
 */

export type CorsAdapter = (url: string) => string;

/**
 * Sets the value of the `crossorigin` HTML attribute whenever ReGraph is trying to load an image
 * from a third-party domain.
 *
 * @param adapter A callback function which takes a URL of the CORS image as an argument and returns
 * the value of the `crossorigin` HTML attribute as a string.
 *
 * @example
 * import { setCorsAdapter } from 'regraph/config';
 *
 * setCorsAdapter((url) => {
 *   if (url.startsWith('https://regraph.io/')) {
 *     return 'use-credentials';
 *   } else {
 *     return 'anonymous'
 *   }
 * });
 */
export function setCorsAdapter(adapter: CorsAdapter): void;
