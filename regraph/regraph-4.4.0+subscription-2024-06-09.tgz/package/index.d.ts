/*
 * Type definitions for ReGraph.
 * 
 * Copyright © 2011-2023 Cambridge Intelligence Limited.
 * All rights reserved.
*/

import { Component, HTMLProps, ReactNode } from 'react';



/** Helper component to manage font icons. Ensures fonts are loaded before rendering children. */
export class FontLoader extends Component<{ config: object; children?: ReactNode }, {}> {}


/** A dictionary of nodes and/or links. */
export type Items<T = any> = Index<Node<T> | Link<T>>;

export type IndexablePropertyKeys<T = any> = T extends object
  ? keyof T & (string | number)
  : string | number;

export type CombinedProperties<
  T,
  C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>,
> = T extends object ? Pick<T, C & keyof T> : T;

export type ComboLink<T, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>> = {
  combo1: CombinedProperties<T, C> | Node<T>;
  combo2: CombinedProperties<T, C> | Node<T>;
};

export type ItemOrCombo<T, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>> =
  | Node<T>
  | Link<T>
  | CombinedProperties<T, C>
  | ComboLink<T, C>;

export type ItemsWithCombos<
  T,
  C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>,
> = Index<ItemOrCombo<T, C>>;

export type DeepNullable<T> = T extends object
  ? {
      [P in keyof T]: DeepNullable<T[P]> | null;
    }
  : T | null;

/**
  * A ReGraph Chart component for visualizing connected data.
  */
export class Chart<
  T = any,
  C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>,
> extends Component<Chart.Props<T, C>, {}> {
  /**
    * Generates a static image of the current Chart, encoded as a base64 PNG.
    * The navigation controls and overview window are not drawn into the image.
    * See the `export` API for vector and high resolution functionality.
    * @param options
    * @returns Returns a Promise which resolves to an image encoded in a data URL.
    */
  image(options?: Chart.ImageOptions): Promise<string>;

  /**
    * **BETA** Exports a static image of the Chart. The exported image is encoded in a blob URL.
    * Export is in beta from v3.1.
    *
    * @param options Options for the exported image.
    * @returns Resolves to an object containing an image data URL and a `download` function.
    */
  export(options?: ExportOptions): Promise<ExportResult>;

  /**
    * Adds a temporary animated halo effect to a node or link.
    * @param id The id (or object of id properties) for the items to be animated.
    * @param options
    */
  ping(id: string | Items | Index<boolean>, options?: Chart.PingOptions): void;

  /**
    * Converts world coordinates (absolute positions relative to the center of the chart) into view coordinates (relative to the top-left of the viewport) and is dependent on the current view (zoom and pan).
    * If in map mode, the passed world coordinates should represent longitude (`worldX`) and latitude (`worldY`).
    * @return The view coordinates as an object with `x`, `y` properties.
    */
  viewCoordinates(worldX: number, worldY: number): Chart.Position;

  /**
    * Converts view coordinates (relative to the top-left of the viewport) into world coordinates (absolute positions relative to the center of the chart).
    * @return The world coordinates as an object with `x`, `y` properties. If in map mode, will return `lng`, `lat` properties instead.
    */
  worldCoordinates(viewX: number, viewY: number): Chart.Position | Location;

  /**
    * Pan the chart in the direction specified.
    */
  pan(direction: 'left' | 'right' | 'up' | 'down', options?: Chart.ViewChangeOptions): void;

  /**
    * Zoom the chart in the manner specified.
    */
  zoom(direction: 'in' | 'out', options?: Chart.ViewChangeOptions): void;

  /**
    * Fit the chart to the items specified.
    *
    * @param items The items to zoom to. You can either specify a shorthand string like
    * 'all' or a list or dictionary of items to fit to.
    */
  fit(
    items: 'all' | 'selection' | 'height' | string[] | Index<any>,
    options?: Chart.ViewChangeOptions,
  ): void;

  /**
    * **ALPHA** Returns a dictionary of info objects on all chart items, or a specified
    * item if a valid id is passed in.
    * The function is intended for use in integration tests and it is in alpha from v3.7.
    *
    * @param id An optional parameter to specify the id of the item to retrieve.
    * @returns An object with an `item` property detailing the item's base properties and an `overwrite` property detailing any currently applied interaction styling.
    * If called without arguments, returns a dictionary of items indexed by ids.
    */
  getItemInfo(id?: string): Chart.ItemInfo<T, C> | Index<Chart.ItemInfo<T, C>> | undefined;

  /**
    * **ALPHA** Returns an object with information about the item or sub-item at the specified view coordinates.
    * The function is intended for use in integration tests and it is in alpha from v3.7.
    *
    * @param x The x view coordinate to be queried.
    * @param y The y view coordinate to be queried.
    * @returns An object with an `id` property of the parent item, an `item` property detailing the item, and a `subItem` property detailing the sub-item.


    */
  getItemAtViewCoordinates(x: number, y: number): Chart.ItemAtViewCoordinates<T, C> | null;

  /**
    * **ALPHA** Returns an object with the x and y view coordinates of the specified item or sub-item.
    * The function is intended for use in integration tests and it is in alpha from v3.7.
    *
    * @param id The id of the item to query.
    * @param subItem If applicable, an object describing the sub-item to query.
    * @returns The view coordinates as an object with `x`, `y` properties.
    */
  getViewCoordinatesOfItem(id: string, subItem?: SubItem): Chart.Position | undefined;
}

export namespace Chart {
  /**
    * All the props for the ReGraph Chart component.
    */
  interface Props<T = any, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>>
    extends Pick<
      HTMLProps<Chart>,
      Exclude<
        keyof HTMLProps<Chart>,
        | 'onChange'
        | 'onClick'
        | 'onContextMenu'
        | 'onDoubleClick'
        | 'onDrag'
        | 'onDragEnd'
        | 'onDragOver'
        | 'onDragStart'
        | 'onHover'
        | 'onLinkAggregation'
        | 'onPointerDown'
        | 'onPointerMove'
        | 'onPointerUp'
        | 'onViewChange'
        | 'onWheel'
      >
    > {
    /**
      * A dictionary of nodes and links, where each property is an item id and each value is the
      * definition of that item.
      */
    items?: Items<T>;

    /**
      * A dictionary containing x/y positions for each node in the chart. Setting `positions` to an
      * empty object will cause the Chart to run a layout and return new positions via the
      * `onChange` handler.
      * */
    positions?: Positions;

    /**
      * The currently active layout, used to position any nodes without an entry in the `positions`
      * object. Setting this will run a layout and may cause node positions to change.
      */
    layout?: LayoutOptions;

    /**
      * Settings to precisely control the view of the chart (note that all properties must be
      * specified).
      */
    view?: View;

    /** A dictionary with a truthy property for each selected item. */
    selection?: Index<boolean | Node | Link | Number>;

    /** Specifies options on the chart. */
    options?: Options;

    /** Controls animations on the chart. */
    animation?: AnimationOptions;

    /** If the chart receives a `className`, it will not apply any default styles. We recommend styling the chart's parent element, rather than passing a `className` to the chart itself. */
    className?: string;

    /**
      * Set to true to enable map mode. Note that Leaflet must be available in the global scope for map mode to work.
      * @default false
      */
    map?: boolean;

    /**
      * Specifies how nodes should be grouped into combos.
      * Defines a hierarchy of properties on the `data` object to combine by, and specifies how deeply nodes
      * should be combined within this hierarchy.
      *
      * Setting the `combine` property to a new object will cause the `onCombineNodes` and `onCombineLinks` event handlers to be called,
      * allowing you to update the styles of all combos and summary links.
      * @example
      * <Chart
      *   combine={{
      *     // Combine items first by City, then by State, then by Country
      *     properties: ['City', 'State', 'Country'],
      *     // Combine items only one level deep, ie, just by City
      *     level: 1
      *   }}
      * />
      */
    combine?: CombineOptions<T, C>;

    /**
      * Standard styling properties for the element. We recommend styling the chart's parent element, not the chart itself. Default is:
      * ```
      * {
      *   position: 'relative',
      *   height: '100%',
      *   minHeight: '100px',
      *   width: '100%',
      * }
      * ```
      */
    style?: object;

    /**
      * **BETA** Controls whether one or more links between a pair of nodes are displayed as an aggregate link.
      * Set to true to aggregate all the links between each pair of nodes.
      * Note that:
      * * Graph functions ignore aggregate links and calculate the results based on the unaggregated chart.
      * * Aggregate links cannot be backgrounded or hidden directly.
      * To background them or hide them, you need to set this for all of their child links instead.
      *
      * Aggregate links are in beta from v4.4.
      * @default false
      */
    aggregateLinks?: boolean | AggregateLinksOptions;

    /**
      * Invoked whenever the chart triggers a change of state. Typically caused by layouts and user interactions.
      */
    onChange?: onChangeHandler<T, C>;
    /**
      * Invoked when the user clicks or taps on the chart surface.
      *
      * Default actions depending on the clicked item:
      * * Node or link: Selects the item (adds to selection if consistentCtrl is pressed).
      * * Background: Deselects all.
      * * Navigation controls: Performs the navigation action.
      * * Overview icon: Opens or closes the overview window.
      *
      * To listen for right click, use the `onContextMenu` event.
      */
    onClick?: onClickHandler;
    /**
      * Invoked on a right click, long press or left click + Ctrl for MacOS.
      *
      * Default action: Suppresses the `onClick` event.
      */
    onContextMenu?: onContextMenuHandler;
    /**
      * Invoked when the user double-clicks or double-taps on the chart surface.
      *
      * Default action: Suppresses the `onClick` event.
      */
    onDoubleClick?: onDoubleClickHandler;
    /**
      * Invoked continuously while the cursor moves during a drag.
      */
    onDrag?: onDragHandler<T, C>;
    /**
      * Invoked when the drag is finished and pointer is released, or when the drag is canceled.
      *
      * Default actions depending on the drag `type`:
      *
      * * 'node' or 'link' - Moves selected items to their final positions. Prevent the default action to snap the drag back.</li>
      * * 'marquee' - Updates the chart selection.</li>
      * * 'pan' or 'overview' - Accepts the final viewport position.</li>
      * * 'create-link' - Creates the link.</li>
      */
    onDragEnd?: onDragEndHandler<T, C>;
    /**
      * Invoked when the cursor moves over an item during a drag.
      */
    onDragOver?: onDragOverHandler<T, C>;
    /**
      * Invoked when a drag is started.
      *
      * Default action: Creates a dragger. Prevent the default action to disable dragging.
      */
    onDragStart?: onDragStartHandler<T, C>;
    /**
      * Invoked when the user hovers over an item for a specified time. You can modify the delay in the `hoverDelay` Chart option. Only invoked when the hover id changes.
      * To apply custom styling when an item is hovered over, consider using `onItemInteraction`.
      */
    onHover?: onHoverHandler;
    /**
      * Invoked when the pointer presses down on the chart surface.
      */
    onPointerDown?: onPointerDownHandler;
    /**
      * Invoked continuously while the pointer moves on the chart surface.
      */
    onPointerMove?: onPointerMoveHandler;
    /**
      * Invoked when the pointer is released.
      */
    onPointerUp?: onPointerUpHandler;

    /**
      * Invoked continuously when the chart view changes, e.g. during zooming or panning.
      */
    onViewChange?: onViewChangeHandler;

    /**
      * Invoked continuously while the user is rotating a mouse wheel or scrolling using a trackpad.
      *
      * Default action: Animated zoom in or out.
      */
    onWheel?: onWheelHandler;

    /**
      * Invoked each time a combo is created or updated. You can adjust the
      * style of the combo by using the `setStyle` function. You can optionally
      * include a string `id` property if you wish to use your own identifiers instead of
      * the default. These must be unique.
      * @example
      * <Chart onCombineNodes={
      *   (comboDefinition) => {
      *      const { nodes, combo, id, setStyle } = comboDefinition;
      *      setStyle({
      *        // insert any styling properties
      *        open: false,
      *        label: {
      *          text: combo.country,
      *        }
      *      });
      *   }
      * }/>
      */
    onCombineNodes?: onCombineNodesHandler<T, C>;

    /**
      * Invoked each time a summary link is created or updated. You can adjust the
      * style of the summary link by calling `setStyle` with an object with style information. You can optionally
      * include a string `id` property if you wish to use your own identifiers instead of
      * the default. These must be unique.
      * @example
      * <Chart onCombineLinks={
      *   (summaryDefinition) => {
      *      const { links, id1, id2, id, setStyle } = summaryDefinition;
      *      setStyle({
      *        // insert any styling properties
      *        width: Math.sqrt(Object.keys(links).length)
      *      });
      *   }
      * }/>
      */
    onCombineLinks?: onCombineLinksHandler<T>;

    /**
      * **BETA** Invoked each time an item or sub-item is hovered or selected.
      * The styling set by the event's `setStyle` function is only applied during the user
      * interaction and cleared once the interaction is over.
      * You can modify the hover delay in the `hoverDelay` Chart option.
      *
      * If both the `onItemInteraction` event and the `selection` prop
      * are used to style an item, the styling in `selection`
      * takes precedence. Set `selection: false` to override this.
      *
      * The `onItemInteraction` event is in beta from v3.6.
      */
    onItemInteraction?: onItemInteractionHandler<T>;

    /**
      * **BETA** Invoked each time the chart has finished updating.
      * The event is in beta from v3.7.
      */
    onUpdateComplete?: () => void;

    /**
      * **BETA** Invoked each time an aggregate link is created, updated or deleted.
      *
      * To style an aggregate link, call `setStyle` with an object with style information.
      * You can optionally include a string id property to use your own (unique) identifier instead of the default.
      *
      * Default action: Creates an aggregate link. Prevent the default action to prevent the creation of the link, and keep all links unaggregated.
      *
      * The `onLinkAggregation` event is in beta from v4.4.
      *
      * @example
      * <Chart onLinkAggregation={
      *   (aggregateLinkDefinition) => {
      *      const { links, id1, id2, id, aggregateByValue, change, setStyle } = aggregateLinkDefinition;
      *      setStyle({
      *        // insert any styling properties
      *        width: Math.sqrt(Object.keys(links).length)
      *      });
      *   }
      * }/>
      */
    onLinkAggregation?: onLinkAggregationHandler;
  }

  interface EventModifierKeys extends ModifierKeys {}

  interface PointerEvent extends BasePointerEvent {
    /** The id of the target item. */
    id: string | null;
    /** An object containing details of the targeted sub-item, if applicable. */
    subItem: SubItem | null;
  }

  interface PreventablePointerEvent extends PointerEvent, PreventDefault {}

  type DraggerType =
    | 'pan'
    | 'marquee'
    | 'create-link'
    | 'slider'
    | 'overview'
    | 'node'
    | 'map'
    | null;
  interface DragEventProps<T = any, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>>
    extends PointerEvent {
    /** If the `type` is 'node', contains the list of nodes being dragged. */
    draggedItems: ItemsWithCombos<T, C>;
  }

  interface DragEndEvent<T = any, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>>
    extends DragEventProps<T, C>,
      PreventDefault {
    /** The type of drag. */
    type: DraggerType;
  }

  interface DragEvent<T = any, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>>
    extends DragEventProps<T, C> {
    /** The type of drag. */
    type: DraggerType;
  }

  interface DragOverEvent<T = any, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>>
    extends DragEventProps<T, C> {
    /** The type of drag. */
    type: 'node';
  }

  interface DragStartOptions {
    /**
      * Set to false to drag child nodes independently of their parent combos.
      */
    includeCombos?: boolean;
    /** The type of drag. */
    type?: 'marquee' | 'node' | 'pan';
    /**
      * Creates a temporary link dragger which will draw a link between the target node
      * and the cursor.
      */
    dummyLink?: boolean | LinkStyle<any>;
  }

  interface DragStartEvent<T = any, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>>
    extends DragEventProps<T, C>,
      PreventDefault {
    /** The type of drag. */
    type: Exclude<DraggerType, 'create-link'>;
    /** Call to set options for the drag. */
    setDragOptions: (options: DragStartOptions) => void;
  }

  type ViewChangeEvent = ViewOptions | MapViewOptions;

  interface WheelEvent extends BaseWheelEvent {}

  type onChangeHandler<T = any, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>> =
    /**
      * @param change An object describing the change.
      */
    (change: ChangeEvent<T, C>) => void;

  type onClickHandler = (props: PreventablePointerEvent) => void;
  type onContextMenuHandler = (props: PreventablePointerEvent) => void;
  type onDoubleClickHandler = (props: PointerEvent) => void;
  type onDragEndHandler<T, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>> = (
    props: DragEndEvent<T, C>,
  ) => void;
  type onDragHandler<T, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>> = (
    props: DragEvent<T, C>,
  ) => void;
  type onDragOverHandler<T, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>> = (
    props: DragOverEvent<T, C>,
  ) => void;
  type onDragStartHandler<T, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>> = (
    props: DragStartEvent<T, C>,
  ) => void;
  type onHoverHandler = (props: PointerEvent) => void;
  type onPointerDownHandler = (props: PointerEvent) => void;
  type onPointerMoveHandler = (props: PointerEvent) => void;
  type onPointerUpHandler = (props: PointerEvent) => void;
  type onViewChangeHandler = (props: ViewChangeEvent) => void;
  type onWheelHandler = (props: WheelEvent) => void;

  /** Signature for the onCombineNodes event handler. Accepts the type of the combo defnition as an argument. */
  type onCombineNodesHandler<
    T = any,
    C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>,
  > =
    /**
      * @param comboDefinition An object describing the combo and its contents.
      * @returns void
      */
    (comboDefinition: CombineNodesEvent<T, C>) => void;

  type onCombineLinksHandler<T = any> =
    /**
      * @param summaryDefinition An object describing the summary link and its contents.
      * @returns void
      */
    (summaryDefinition: CombineLinksEvent<T>) => void;

  type onItemInteractionHandler<
    T = any,
    C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>,
  > = (itemInteraction: ItemInteractionEvent<T, C>) => void;

  type onLinkAggregationHandler =
    /**
      * @param aggregateLinkDefinition An object describing the aggregate link and its contents.
      */
    (aggregateLinkDefinition: LinkAggregationEvent) => void;

  /** The options for the Chart's combine prop. */
  interface CombineOptions<T = any, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>> {
    /**
      * The hierarchy of properties which are used to control combos. These properties come from the `data` property
      * of nodes. Nodes with matching property values are combined into a single combo that represents the property value itself.
      * The first property in the array is the deepest/innermost combo, and the last is the outermost combo.
      */
    properties: C[];

    /**
      * The combo nesting level.
      * A value of 0 means no nodes will be combined, 1 combines nodes using the first property in the
      * `properties` array, 2 combines by the first and then the second properties in the array, and so on.
      * If `level` is not specified then ReGraph uses all properties in the `properties` array.
      */
    level?: number;
    /**
      * The shape of combos.
      * @default 'circle'
      */
    shape?: 'rectangle' | 'circle';
  }

  /** Describes a node's position. */
  interface Position {
    x: number;
    y: number;
  }

  /** Dictionary of positions for each node in the Chart. */
  type Positions = Index<Position>;

  /** Options for ordering nodes within the same `level` in sequential layout.  */
  interface OrderByOptions {
    /** The key of the custom data value on the node's `data` property that orders the items within the same `level` in sequential layout.
      * When specified, items are ordered alphanumerically and in the descending order unless `sortBy` is also set. */
    property?: string;
    /** The direction of ordered items.
      * @default 'descending'
      */
    sortBy?: 'ascending' | 'descending';
  }

  /** Options for the Chart's layout prop. */
  interface LayoutOptions {
    /**
      * The layout name to apply. 'Standard' and 'tweak' layouts are deprecated since 4.0.
      * @default 'organic'
      */
    name?: 'organic' | 'sequential' | 'structural' | 'radial' | 'lens' | 'standard' | 'tweak';

    /** A node id or an array of ids that should be at the top of the sequential or in the centre of the radial layout.
      * Components without `top` specified are unchanged during the layout but can be arranged by packing.
      * Required for the radial layout unless `level` is specified. If both `level` and `top` are specified, `top` is ignored.
      */
    top?: string | string[];

    /**
      * The name of the custom property on the node's `data` property that defines which level a node belongs to in the radial or sequential layout.
      * The property must contain a numeric value, where the lowest number is the top of the hierarchy.
      * If both the `level` and `top` properties are specified, `top` is ignored.
      */
    level?: string;

    /**
      * The packing mode to arrange subgraphs. Not used by 'lens'. The 'aligned' packing is only available for sequential and it's the default option for this layout.
      * @default 'circle' | 'aligned'
      */
    packing?: 'circle' | 'rectangle' | 'aligned';

    /**
      * Controls how close nodes are spaced, with higher values making nodes closer. Ranges from 0-10.
      * @default 5
      */
    tightness?: number;

    /**
      * The orientation of sequential layouts.
      * @default 'down'
      */
    orientation?: 'down' | 'right' | 'up' | 'left';

    /**
      * The order of items within the same `level` in sequential layout.
      */
    orderBy?: string | OrderByOptions;

    /**
      * Controls the shape of links. Most effective with sequential layouts.
      * Curved links will join nodes in a way that aligns with the `orientation` property.
      * @default false
      */
    curvedLinks?: boolean;

    /**
      * The spacing between levels in sequential layouts. Values must be positive.
      * @default 1
      */
    stretch?: number;

    /**
      * The positioning of nodes that share the same neighbors and `level` in the sequential layout.
      * If `property` is set in `orderBy`, `stacking` only applies to nodes also sharing the same `property` value.
      */
    stacking?: StackingOptions;
  }
  interface StackingOptions {
    /**
      * If set to 'grid', four or more same-level nodes with identical connections are stacked in a grid.
      * @default 'none'
      */
    arrange: 'grid' | 'none';
  }

  /** Options to control the aggregate links behavior. */
  interface AggregateLinksOptions {
    /**
      * The key of the custom data on the child link's `data` property to be used to aggregate links together.
      * One aggregate link is created between two nodes for each value of the data.
      */
    aggregateBy: string;
    /**
      * Controls whether separate aggregate links are created for each of the directions the child links could have.
      * @default false.
      */
    aggregateByDirection?: boolean;
  }

  /** Options to control animation between Chart states. */
  interface AnimationOptions {
    /**
      * Animates transitions between chart states.
      * @default true
      */
    animate?: boolean;

    /**
      * The total duration in milliseconds in which animations should run. This time is shared between all animations on a particular update.
      * @default 250
      */
    time?: number;
  }

  /** General type to represent the valid view values. */
  type View = ViewOptions | MapViewOptions;

  type FitOptions = 'auto' | 'none' | 'all' | 'selection' | Items;

  /** An object describing the Chart pan and zoom (see MapViewOptions for map mode view options). */
  interface ViewOptions {
    /**
      * The zoom level.
      */
    zoom: number;

    /**
      * The x-offset (horizontal pan).
      */
    offsetX: number;

    /**
      * The y-offset (vertical pan).
      */
    offsetY: number;
  }

  /** An object describing the Chart's zoom and position in map mode. */
  interface MapViewOptions {
    /**
      * The latitude and longitude of the center point of the map, as an array of the form [lat, long].
      */
    mapCenter: [number, number];

    /**
      * The zoom level of the map.
      */
    mapZoom: number;
  }

  /** Options to control the appearane and behavior of links. */
  interface LinkOptions {
    /**
      * Controls the size of arrows on links. Note that arrowhead size is proportional to the link width.
      * @default 'normal'
      */
    arrowSize?: 'normal' | 'small' | 'large' | 'xlarge';

    /**
      * Whether link ends should avoid node labels.
      * @default true
      */
    avoidLabels?: boolean;

    /**
      * Controls the spacing between link ends and nodes.
      * @default 'tight'
      */
    endSpacing?: 'loose' | 'tight';

    /**
      * Controls the orientation of multiple glyphs on links without labels. If set to 'along', glyphs are drawn along the link. If set to 'horizontal', glyphs are drawn horizontally.
      * @default 'horizontal'
      */
    glyphOrientation?: 'along' | 'horizontal';

    /**
      * Only for links with a color gradient. Controls the size of the fraction at the midpoint of the link where the color transition occurs. The value is between 0 and 1, with 0 providing an immediate transition between colors. The rest of the link is drawn with solid colors.
      * @default 0.75
      */
    gradientTransition?: number;

    /**
      * Rotates labels and glyphs on links to match the link orientation. Note that enabling `inlineLabels` overrides the `glyphOrientation` option.
      * @default false
      */
    inlineLabels?: boolean;

    /**
      * Controls how links are selected when dragging a selection marquee.
      * @default 'center'
      */
    marqueeSelection?: 'center' | 'ends' | 'off';
  }

  /** Options to control the appearance and behavior of labels on Chart items. */
  interface LabelOptions {
    /**
      * The default font family to use, such as 'arial' or 'helvetica'.
      * If the font isn't supported by the browser, or if none is set, 'sans-serif' is used.
      * @default 'sans-serif'
      */
    fontFamily?: string;

    /**
      * If set to true, labels are drawn over glyphs. If false, glyphs are drawn over labels.
      * @default true
      * */
    legacyGlyphAndLabelOrdering?: boolean;

    /**
      * An integer to move the label text up or down. Useful only for certain fonts where the baseline is irregular (e.g. Open Sans).
      */
    offset?: number;

    /**
      * Truncates item labels which exceed a particular length.
      */
    maxLength?: number;

    /**
      * If a label is truncated, this setting will reveal the whole label when the user hovers over it.
      * @default true
      */
    showOnHover?: boolean;
  }

  /** Options to control the appearance of the selected item. */
  interface SelectionOptions {
    /**
      * Sets the color of the selection indicator for items.
      * Adds colored halos to nodes, colored selection markers to the middle of links
      * and changes background color of node and link labels.
      * When setting `color` for node that has an array of node labels,
      * the node label background color only changes for labels
      * that don't have a set `backgroundColor` property.
      * @default 'rgb(255, 109, 102)'
      */
    color?: string;

    /**
      * Sets the font color of any labels on the selected item.
      * When setting `labelColor` for node that has an array of node labels,
      * the node label font color only changes for labels
      * that don't have a set `color` property.
      * @default 'white'
      */
    labelColor?: string;
  }

  /** Options to control the appearance and behavior of the Chart's map mode. */
  interface MapOptions {
    /**
      * Pass options directly into the Leaflet constructor. See the Leaflet API for more details.
      */
    leaflet?: object;

    /**
      * An option to set the url template for map tiles.
      * Accepts either a string in the form of `http://example.com/path/{z}/{x}/{y}.png`,
      * or an object in the Leaflet `TileLayer` options format
      * with an additional `url` property.
      * If the url template isn't set, OpenStreetMap is used as a default tile provider.
      * If set to null, the tile layer isn't created.
      */
    tiles?: object | string;
  }

  /** Describes the options supported in the Chart's options prop. */
  interface Options {
    /**
      * The color to use for the background of the chart itself.
      * @default 'white'
      */
    backgroundColor?: string;

    /**
      * Set to give the chart a linear background gradient. The gradient runs from top to bottom of the chart.
      * To create a gradient you must define an array of at least two color/stop objects.
      * @example
      * <Chart options={{
      *   backgroundGradient: [
      *     { color: 'yellow', stop: 0 },
      *     { color: 'red', stop: 1 },
      *   ],
      * }}/>
      */
    backgroundGradient?: GradientStop[];

    /**
      * Options to control combo behavior.
      */
    combo?: ComboOptions;

    /**
      * The color theme of the navigation and overview window controls.
      * @default 'light'
      */
    controlTheme?: 'light' | 'dark';

    /**
      * The color to use for the navigation and overview window control.
      * Only the hue and saturation values of the color are used: the lightness is fixed.
      */
    controlColor?: string;

    /**
      * If true, drag operations will pan the chart automatically
      * if the mouse or touch position moves near the edge of or outside the chart area.
      * If false, the chart will not pan if the mouse or touch position moves near the
      * edge of the chart area during a drag operation, and the drag will be canceled
      * if the mouse moves outside the chart area.
      * @default true
      */
    dragPan?: boolean;

    /**
      * The opacity level of faded items. In the range 0 to 1, where 0 is totally transparent.
      * @default 0.2
      */
    fadeOpacity?: number;

    /**
      * Controls how the chart should adapt the view to fit incoming changes.
      * @default 'auto'
      */
    fit?: FitOptions;

    /**
      * If true, dragging the chart background drags all items.
      * If false, dragging the chart background draws a bounding box for selecting items.
      * @default true
      */
    handMode?: boolean;

    /**
      * The number of milliseconds delay before the `onItemInteraction` and `onHover` events are
      * triggered.
      * @default 150
      */
    hoverDelay?: number;


    /**
      * The default font family to use for font icons, such as 'FontAwesome' or 'Octicon'.
      * If the font isn't supported by the browser, or if none is set, 'sans-serif' is used.
      * @default 'sans-serif'
      */
    iconFontFamily?: string;

    /**
      * Sets the position and scale for images and font icons on nodes.
      * The object accepts properties
      * where property names are image or font icon paths and property values are the values to be adjusted.
      *
      * The `imageAlignment` property does not apply to font icons on node labels. Use `fontSize` for scaling and
      * `position` and `margin` for positioning instead.
      * @example
      * <Chart options={{
      *   imageAlignment: {
      *     'fa-user': { size: 2 },
      *     '/assets/img/logo.png': { size: 1.5 }
      *   }
      * }}/>
      *
      */
    imageAlignment?: Index<ImageAlignmentOptions>;

    /**
      * Options to control the appearance of labels on items.
      */
    labels?: LabelOptions;

    /**
      * Options to control the appearance of links.
      */
    links?: LinkOptions;

    /**
      * Settings for the logo to be displayed in a corner of the chart.
      */
    logo?: LogoOptions;

    /**
      * Specifies options for the Leaflet map.
      * @example
      * <Chart options={{
      *   map: {
      *     tiles: 'http://example.com/path/{z}/{x}/{y}.png'
      *   }
      * }}/>
      */
    map?: MapOptions;

    /**
      * Sets the maximum zoom for items, from `minZoom` to 4. We suggest a value of around 1 to have an optimal result.
      * @default 4
      */
    maxItemZoom?: number;

    /**
      * Sets the minimum zoom for the view.
      * Use a smaller value to allow the chart to be zoomed out further.
      * The value can be from 0.001 to 1.
      * @default 0.05
      */
    minZoom?: number;

    /**
      * An object whose properties are the settings for the navigation controls.
      * For brevity, you can pass a value of false to hide the navigation controls.
      */
    navigation?: NavigationOptions | boolean;

    /**
      * An object whose properties are the settings for the overview window.
      * For brevity, you can pass a value of false to hide the overview window.
      */
    overview?: OverviewOptions | boolean;

    /**
      * Options to control the appearance of selected items. Set to false or an empty object to disable selection styles.
      */
    selection?: SelectionOptions | false;

    /**
      * An object whose properties are the settings for the watermark in the center of the chart.
      */
    watermark?: WatermarkOptions;
  }

  /** Defines a gradient stop position and color. */
  interface GradientStop {
    /** The color for the specified location. */
    color?: string;

    /**
      * The point at which the background color is set.
      * A value of 0.4 would mean that the background takes on the specified color at 40% of the chart's height
      * (the top of the chart is at 0%).
      * If there are colors on either side of this stop, then the background color
      * will transition linearly from/to these colors.
      * We recommend using values between 0 and 1.
      */
    stop?: number;
  }

  /** Options to control the appearance of the watermark. */
  interface WatermarkOptions {
    /**
      * The vertical alignment of the watermark text.
      * @default 'center'
      */
    align?: 'top' | 'bottom' | 'center';

    /**
      * Sets a text label on the watermark.
      */
    label?: Label;

    /**
      * Sets the watermark image as a URL.
      */
    image?: string;
  }

  /** Options to control the appearance of the logo. */
  interface LogoOptions {
    /**
      * The position of the logo.
      * @default 'ne'
      */
    position?: 'ne' | 'nw' | 'se' | 'sw';

    /**
      * The URL of the logo to be displayed, or null for no logo. On Retina devices, KeyLines will also check for a double-resolution @2x version of the logo, e.g. 'path/to/images/myAwesomeLogo@2x.png'.
      */
    image?: string;

    /**
      * The horizontal offset in pixels from the logo's default position.
      * @default 0
      */
    x?: number;

    /**
      * The vertical offset in pixels from the logo's default position.
      * @default 0
      */
    y?: number;
  }

  /** Options to control combo behavior */
  interface ComboOptions {
    /**
      * When true, provides default combo selection behavior.
      * Nodes and links that are selected and within combos or summary links, or connected to a combo,
      * are brought into the foreground of the chart along with any neighbors they have.
      * This includes showing the contents of summary links. Other items in the chart are faded. If chart items
      * have `fade` set explicitly these items will not be altered.
      * @default true
      */
    autoSelectionStyle?: boolean;
  }

  /** Options to control the appearance and behavior of the Chart's navigation controls.  */
  interface NavigationOptions {
    /**
      * The position of the navigation controls.
      * @default 'nw'
      */
    position?: 'ne' | 'nw' | 'se' | 'sw';

    /**
      * Whether the navigation controls are displayed.
      * @default true
      */
    visible?: boolean;

    /**
      * The horizontal offset in pixels from the navigation controls' default position.
      * @default 0
      */
    x?: number;

    /**
      * The vertical offset in pixels from the navigation controls' default position.
      * @default 0
      */
    y?: number;
  }

  /** Options to control the appearance and behavior of the overview window. */
  interface OverviewOptions {
    /**
      * Whether the icon the user can click on to open/close the overview is shown.
      * @default true
      */
    showIcon?: boolean;

    /**
      * The position of the overview window.
      * @default 'se'
      */
    position?: 'ne' | 'nw' | 'se' | 'sw';

    /**
      * Whether the overview window is actually shown.
      * @default false
      */
    visible?: boolean;

    /**
      * The size of the overview window in pixels.
      * @default 100
      */
    size?: number;

    /**
      * The background color of the overview window.
      * @default 'white'
      */
    backgroundColor?: string;

    /**
      * The border color of the overview window.
      * @default 'light grey'
      */
    borderColor?: string;
  }

  /** Options to control the alignment of a single image or font icon. */
  interface ImageAlignmentOptions {
    /**
      * Sets how far to move the icon horizontally. The value is a percentage from -50 to 50.
      * @default 0
      */
    dx?: number;

    /**
      * Sets how far to move the icon vertically. The value is a percentage from -50 to 50.
      * @default 0
      */
    dy?: number;

    /**
      * The factor by which you want to resize the icon relative to its parent. Must be greater than 0.
      * @default 0
      */
    size?: number;
  }

  /** Describes a change notifiation event published to the onChange event. */
  interface ChangeEvent<T = any, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>> {
    /** Indicates whether the `onChange` event was triggered by user action or internal ReGraph state. */
    why?: 'user' | 'auto';

    /** Contains the positions of all nodes in the chart. */
    positions?: Positions;

    /** Indicates which items are currently selected. */
    selection?: ItemsWithCombos<T, C>;

    /** The current view settings. */
    view?: ViewOptions | MapViewOptions;

    /**
      * The underlying Leaflet map object that is used in map mode.
      * The property is set to the Leaflet map object when the map is shown; when the map is hidden, the property is set to null.
      */
    leaflet?: object;

    /**
      * Indicates the current status of the hand mode option.
      */
    handMode?: boolean;

    /**
      * Indicates the current status of the overview's `visible` option.
      */
    overview?: boolean;
  }

  /** Describes the combo object passed to the onCombineNodes event. Accepts a custom type for the combo definition (also applied to the data prop of all child nodes). */
  interface CombineNodesEvent<
    T = any,
    C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>,
  > {
    /** The default id for this combo. This can be overridden in the combo `setStyle` function. */
    id: string;

    /** The nodes belonging to this combo. */
    nodes: Index<Node<T>>;

    /** An object containing the specific values for the `combine` properties. For example, properties ['county', 'state'] could result in a combo object { county: ‘Cambridge’, state: ‘Massachusetts’ }. */
    combo: CombinedProperties<T, C>;

    /** Use to specify the style of this combo. */
    setStyle: (style: ComboStyle) => void;
  }

  interface ItemInteractionEvent<
    T = any,
    C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>,
  > {
    /** Information about the target aggregate link */
    aggregate?: AggregateLinkInfo;
    /** The `combine` properties of the target combo. */
    combo?: CombinedProperties<T, C>;
    /** True if the target is being hovered over. */
    hovered: boolean;
    /** The id of the target item. */
    id: string;
    /** The targeted item. */
    item: Node<T> | Link<T> | Summary | ComboStyle;
    /** The links inside the target summary link. */
    links?: Index<Link<T>>;
    /** The nodes inside the target combo. */
    nodes?: Index<Node<T>>;
    /** True if the target is selected. */
    selected: boolean;
    /** Sets the style of chart items. You can change the style of any chart item. */
    setStyle(styles: Record<string, DeepNullable<Node<any> | LinkStyle<any> | ComboStyle>>): void;
    /** An event signal that can be aborted by an Abort controller to cancel the styling. */
    signal: AbortSignal;
    /** Details of the sub-item interacted with. */
    subItem?: SubItem | null;
  }

  /** Describes the summary link object passed to the onCombineLinks event. Accepts a custom data prop type for the content links. */
  interface CombineLinksEvent<T = any> {
    /** The default id for this summary link. This can be overridden in the summary link `setStyle` function. */
    id: string;

    /** The links inside this summary link. */
    links: Index<Link<T>>;

    /** The id at one end of the summary link. Note this can be the id of a combo or a node. */
    id1: string;

    /** The id at the other end of the summary link. Note this can be the id of a combo or a node. */
    id2: string;

    /** Use to specify the style of this summary link. */
    setStyle: (style: Summary) => void;
  }

  type ClosedComboStyle = Node;

  export interface AggregateLinkInfo {
    /**
      * The arrow direction of the child links, when `aggregateByDirection: true`. Otherwise is `undefined`.
      */
    aggregateDirection: 'none' | 'both' | 'from' | 'to' | undefined;

    /**
      * The property on links being used to group links by.
      */
    aggregateByProp: string | undefined;

    /**
      * The value of the property being used to group links into aggregate links.
      * This is undefined when `aggregateLinks` prop is set to true.
      */
    aggregateByValue: any;

    /** The aggregate link's contents. */
    links: Index<Link<any>>;
  }

  interface LinkAggregationEvent {
    /**
      * The arrow direction of the child links, when `aggregateByDirection: true`. Otherwise is `undefined`.
      */
    aggregateByDirection: 'none' | 'both' | 'from' | 'to' | undefined;

    /**
      * The value of the property being used to group links into aggregate links.
      * This is undefined when `aggregateLinks` prop is set to true.
      */
    aggregateByValue: any;

    /** Describes the change occuring to the aggregate link. */
    change: 'created' | 'updated' | 'deleted';

    /** The default id for this aggregate link. Can be overridden using the `setStyle` function. */
    id: string;

    /** The id of a node or a combo at one end of the aggregate link.
      * The `id1` is assigned to the id that comes first in alphanumeric order
      * This order may be relevant when using aggregate links with sequential layout
      * without `top` or `level` specified. */
    id1: string;

    /** The id of node or a combo at the other end of the aggregate link.
      * The `id2` is assigned to the id that comes second in alphanumeric order.
      * This order may be relevant when using aggregate links with sequential layout
      * without `top` or `level` specified. */
    id2: string;

    /** The aggregate link's contents. */
    links: Index<Link<any>>;

    /** Specifies the style to be used for this aggregate link. */
    setStyle: (style: AggregateStyle) => void;
  }

  export type GridShapeMode = 'auto' | { rows: number } | { columns: number };

  /** Types of arrangements inside open combos. */
  export type ComboArrangeName = 'none' | 'lens' | 'concentric' | 'grid' | 'auto';

  export interface ComboArrangeOptions {
    /** The arrangement to apply. Circular combos use 'lens' by default, rectangular combos use 'grid' by default.
      * @default 'lens' | 'grid'
      */
    name: ComboArrangeName;
    /** Controls how close items are spaced inside open combos, with higher values making nodes closer. Ranges from 0-10.
      * @default 5 */
    tightness?: number;
  }

  export type ComboArrange = ComboArrangeName | ComboArrangeOptions;

  /** Defines properties for a combo, to be set in the onCombineNode event's onStyle method. */
  interface ComboStyle {
    /**
      * Overrides the default id of the combo.
      */
    id?: string;

    /**
      * Opens the combo so that its children are visible.
      * @default true
      */
    open?: boolean;

    /**
      * Sets the arrangement of items inside an open combo. Accepts a string with the arrangement name or an object to also set additional options.
      */
    arrange?: ComboArrange;

    /**
      * If `arrange` is set to 'grid', this can be set to an object in the form of `{ rows: number }` or `{ columns: number }` to set the row/column dimension of the grid.
      * @default 'auto'
      */
    gridShape?: GridShapeMode;

    /**
      * An array of objects describing the glyphs shown on the combo. Glyphs are not inherited between open and closed combos.
      */
    glyphs?: Glyph[];

    /**
      * Defines a border around the combo. Defaults to a grey border for open combos, and no border for closed combos.
      */
    border?: Node['border'];

    /**
      * The fill color. Defaults to rgba(240,240,240,0.8) for open combos, and grey for closed combos.
      */
    color?: Node['color'];

    /**
      * Defines a label for a combo.
      */
    label?: NodeLabel | NodeLabelContainer | NodeLabelContainer[];

    /**
      * Fades the combo into the background. Defaults to false, unless all the children are faded causing the
      * default to be true.
      */
    fade?: Node['fade'];

    /**
      * Scales the closed combo size by an enlargement factor. When the combo is open, only glyphs and labels are scaled.
      * @default 1
      */
    size?: Node['size'];

    /**
      * Sets the style of the combo when closed. All Node properties are supported on closed combos.
      * @example
      * <Chart onCombineNodes={({setStyle}) => {
      *   setStyle({
      *     // open combo will be white
      *     color: 'white',
      *     closedStyle: {
      *       // closed combo will be blue
      *       color: 'blue',
      *     },
      *   });
      * }}/>
      */
    closedStyle?: ClosedComboStyle;
  }

  /** Defines styling properties for a combo, to be returned to the onCombineNodes callback. */
  interface Combo extends ClosedComboStyle {
    /**
      * Override the default id of the combo.
      */
    id?: string;

    /**
      * Opens the combo so that its children are visible.
      * @default true
      */
    open?: boolean;

    /**
      * Sets how to arrange items within the combo. Circular combos use 'lens' by default, rectangular combos use 'grid' by default.
      * @default 'lens' | 'grid'
      */
    arrange?: ComboArrange;
  }

  /** Defines styling properties for a summary link, to be set in the onCombineLinks event's setStyle method. */
  interface Summary extends LinkStyle<any> {
    /**
      * Override the default id of the summary link.
      */
    id?: string;
    /**
      * Display the summary link.
      * @default true
      */
    summary?: boolean;
    /**
      * Display the summary link's contents. You can supply a boolean to hide or show all child links,
      * or supply a dictionary with truthy values for each child link you want to display.
      * @default false
      */
    contents?: boolean | Index<Link | true>;
  }

  /** Defines styling properties for an aggregate link, to be set in the onAggregateLinks event's setStyle method. */
  interface AggregateStyle extends LinkStyle<any> {
    /** Optional identifier that must be unique and overrides the default id of the aggregate link. */
    id?: string;
  }

  /** Options for the image instance method. */
  interface ImageOptions {
    /**
      * How the view settings are mapped when generating the image.
      * 'chart' fits the whole chart into the image. 'exact' fit uses the same zoom and pan as the component
      * which produces identical image if using the same dimensions as the browser component.
      * This reproduces the view exactly as the user sees it.
      *
      * Note that in map mode, only 'exact' fit is available.
      * @default 'exact'
      * */
    fit?: 'chart' | 'exact';

    /**
      * Height of exported image, in pixels.
      * @default The Chart's current height
      */
    height?: number;

    /**
      * Width of exported image, in pixels.
      * @default The Chart's current width
      */
    width?: number;
  }

  /** Options for the ping instance method. */
  interface PingOptions {
    /**
      * The color to use for the animated effect.
      * @default 'rgb(255,109,102)'
      */
    color?: string;

    /**
      * The width of a link at the end of its animation.
      * @default 40
      */
    linkWidth?: number;

    /**
      * The radius of a halo at the end of its animation.
      * @default 80
      */
    haloRadius?: number;

    /**
      * The width of a halo at the end of its animation.
      * @default 40
      */
    haloWidth?: number;

    /**
      * The number of times the animation should be repeated.
      * @default 1
      */
    repeat?: number;

    /**
      * The time the animation should take, in milliseconds.
      * @default 800
      */
    time?: number;
  }

  /** Options for the imperative view methods. */
  interface ViewChangeOptions {
    /**
      * The time the animation should take, in milliseconds.
      * @default 200
      */
    time: number;
  }

  interface ItemAtViewCoordinates<
    T,
    C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>,
  > {
    item: ItemOrCombo<T, C>;
    subItem: SubItem | null;
    id: string;
  }

  /**
    * Object with information about the chart item.
    */
  export interface ItemInfo<T, C extends IndexablePropertyKeys<T> = IndexablePropertyKeys<T>> {
    /**
      * Object describing the item.
      */
    item: ItemOrCombo<T, C>;
    /**
      * Object detailing any currently active interaction styling that is overwriting the item's base styling.
      */
    overwrite: ItemOrCombo<T, C> | undefined;
  }
}



/**
  * A ReGraph Time Bar component for visualizing connected data over time.
  */
export class TimeBar extends Component<TimeBar.Props, {}> {
  /**
    * Pan the time bar in the direction specified.
    */
  pan(direction: 'forward' | 'backward', options?: TimeBar.ViewChangeOptions): void;

  /**
    * Zoom the time bar in the manner specified.
    */
  zoom(direction: 'in' | 'out', options?: TimeBar.ViewChangeOptions): void;

  /**
    * Fit the time bar to the items specified.
    */
  fit(items: 'all' | string[] | Index<any>, options?: TimeBar.ViewChangeOptions): void;
}

export namespace TimeBar {
  /**
    * All the props for the ReGraph Time Bar component.
    */
  interface Props
    extends Pick<
      HTMLProps<TimeBar>,
      Exclude<
        keyof HTMLProps<TimeBar>,
        | 'onChange'
        | 'onClick'
        | 'onContextMenu'
        | 'onDoubleClick'
        | 'onDragEnd'
        | 'onDragStart'
        | 'onHover'
        | 'onPointerDown'
        | 'onPointerMove'
        | 'onPointerUp'
        | 'onWheel'
      >
    > {
    /**
      * Controls animations on the Time Bar.
      */
    animation?: AnimationOptions;

    /** If the Time Bar receives a `className`, it will not apply any default styles. We recommend styling the Time Bar's parent element, rather than passing a `className` to the Time Bar itself. */
    className?: string;

    /**
      * An indexed list of all the items in the Time Bar. Each item must have a `times` property. See the Item data format.
      */
    items?: Items;

    /**
      * Highlights a time or range of times in the Time Bar using the color defined in the `highlightColor` option.
      *
      * @example <TimeBar
      *   highlight={[
      *     new Date(),
      *     {
      *       start: Date.now() + 1000 * 60 * 60,
      *       end: Date.now() + 3 * 1000 * 60 * 60
      *     }
      *   ]}
      * />
      */
    highlight?: Array<Date | TimeRange>;

    /**
      * Draws a selection line for items with truthy values in the supplied object, or multiple lines if multiple objects are supplied in an array. The maximum number of selection lines is 3.
      * @example <TimeBar
      *   items={items}
      *   selection={[{ node1: true }, { node2: true }]}
      * />
      */
    selection?: Index<boolean | Item> | Index<boolean | Item>[];

    /**
      * Indicates the colors to use for any selection lines drawn.
      * @default 'sunset red', 'dark green' and 'orange'
      * @example <TimeBar
      *   items={items}
      *   selection={[{ node1: true }, { node2: true }]}
      *   selectionColor={["blue", "red"]}
      * />
      */
    selectionColor?: string | string[];

    /**
      * Indicates whether the Time Bar is playing.
      * @default false
      */
    play?: boolean;

    /**
      * Specifies the visible range of the Time Bar.
      */
    range?: TimeRange;

    /**
      * Sets the display mode of the Time Bar to show histogram bars, or a smooth line with shaded area.
      * @default 'histogram'
      */
    mode?: 'smooth' | 'histogram';

    /**
      * Options to control the Time Bar.
      */
    options?: Options;

    /**
      * Standard styling properties for the element. We recommend styling the Time Bar's parent element, not the Time Bar itself. Default is:
      * ```
      * {
      *   position: 'relative',
      *   height: '100%',
      *   minHeight: '100px',
      *   width: '100%',
      * }
      * ```
      */
    style?: object;

    /**
      * Invoked whenever the range of the Time Bar changes. Returns a list of items in range.
      */
    onChange?: onChangeHandler;

    /**
      * Invoked when the user clicks or taps on the time bar surface.
      */
    onClick?: onClickHandler;
    /**
      * Invoked on a right click, long press or left click + Ctrl for MacOS.
      *
      * Default action: Suppresses the onClick event.
      */
    onContextMenu?: onContextMenuHandler;
    /**
      * Invoked when the user double-clicks or double-taps on the time bar surface.
      *
      * Default action: Animated zoom in that centres at the clicked time.
      */
    onDoubleClick?: onDoubleClickHandler;
    /**
      * Invoked when the drag is finished and pointer is released, or when the drag is canceled.
      *
      * Default actions depending on drag `type`:
      *
      * * 'slider' - Accepts the final panned range of the time bar and zooms to fit the view.
      * * other types - Accepts the final panned range of the time bar. Prevent the default action to snap the pan back.
      */
    onDragEnd?: onDragEndHandler;
    /**
      * Invoked when a drag is started.
      *
      * Default actions depending on drag `type`:
      *
      * * 'slider' - Starts dragging the slider.
      * * other types - Starts a pan controlled by the pointer. Prevent the default action to disable panning.
      */
    onDragStart?: onDragStartHandler;
    /**
      * Invoked when the user hovers over an item. Only invoked whenever the hover id changes.
      */
    onHover?: onHoverHandler;
    /**
      *  Invoked when the pointer presses down on the time bar surface.
      * */
    onPointerDown?: onPointerDownHandler;
    /**
      *  Invoked continuously while the pointer moves on the time bar surface.
      * */
    onPointerMove?: onPointerMoveHandler;
    /**
      * Invoked when the pointer is released.
      * */
    onPointerUp?: onPointerUpHandler;
    /**
      * Invoked continuously while the user is rotating a mouse wheel or scrolling using a trackpad.
      *
      * Default action: Animated zoom in or out.
      */
    onWheel?: onWheelHandler;
  }

  type EventTypes = 'bar' | 'area' | 'selection' | 'scale' | 'left' | 'right' | 'slider' | null;

  interface EventModifierKeys extends ModifierKeys {}

  interface PointerEvent extends BasePointerEvent {
    /** The index of the clicked selection point, or null for other click types. */
    index?: number;
    /** The date at the end of the clicked range. */
    end?: Date;
    /** The date at the start of the clicked range. */
    start?: Date;
    /** Index of clicked stack in the bar. Undefined if `type` parameter is not 'bar' or the bar is highlighted. */
    stackIndex?: number;
    /** Values of each stack in the bar. Undefined if `type` parameter is not 'bar' or the bar is highlighted. */
    stackValues?: number[];
    /** A suggested location for the tooltip in the x direction - the center of the bar or selection point. */
    tooltipX: number;
    /** A suggested location for the tooltip in the y direction - the height of the bar or selection point. */
    tooltipY: number;
    /** The type of clicked item. */
    type: EventTypes;
    /** The value of either the bar or selection. */
    value?: number;
  }

  interface PreventablePointerEvent extends PointerEvent, PreventDefault {}

  interface WheelEvent extends BaseWheelEvent {}

  type onChangeHandler =
    /**
      * @param change An object describing the change.
      */
    (change: ChangeEvent) => void;

  type onClickHandler = (props: PointerEvent) => void;
  type onContextMenuHandler = (props: PreventablePointerEvent) => void;
  type onDoubleClickHandler = (props: PreventablePointerEvent) => void;
  type onDragEndHandler = (props: PreventablePointerEvent) => void;
  type onDragStartHandler = (props: PreventablePointerEvent) => void;
  type onHoverHandler = (props: PointerEvent) => void;
  type onPointerDownHandler = (props: PointerEvent) => void;
  type onPointerMoveHandler = (props: PointerEvent) => void;
  type onPointerUpHandler = (props: PointerEvent) => void;
  type onWheelHandler = (props: WheelEvent) => void;

  /** Options to control animations on the Time Bar. */
  interface AnimationOptions {
    /**
      * If true, animates changes.
      * @default true
      */
    animate?: boolean;

    /**
      * The total duration in milliseconds in which animations should run.
      * @default 250
      */
    time?: number;
  }


  /**
    * **DEPRECATED** Specifies a time range from start until end. Deprecated since v2.0. Use TimeRange instead.
    */
  interface Range {
    /** The start of the range. */
    dt1: Date | number;

    /** The end of the range. */
    dt2: Date | number;
  }

  /** Specifies a time range from start until end. */
  interface TimeRange {
    /** The start of the range. */
    start: Date | number;

    /** The end of the range. */
    end: Date | number;
  }

  /** Options to control the locale formatting on dates and times. */
  interface LocaleOptions {
    /**
      * An array of two strings giving the text to use for AM and PM when displaying 12-hour clock times. Optionally this array may contain two more strings, which are used to label Time Bar intervals representing the first and second halves of days.
      * @default ['AM', 'PM']
      */
    ampm?: string[];

    /**
      * A flag indicating whether the 12-hour clock should be used to display times. If false, the 24-hour clock is used.
      * @default true
      */
    h12?: boolean;

    /**
      * A prefix used to indicate halves of years.
      * @default 'H'
      */
    half?: string;

    /**
      * An array of strings giving the full names of the months, starting with January.
      * @default ['January', etc]
      */
    longMonths?: string[];

    /**
      * A string controlling the order of dates. Supported values are 'dmy' for day-month-year, and 'mdy' for month-day-year.
      * @default 'mdy'
      */
    order?: string;

    /**
      * A prefix used to indicate quarters of years.
      * @default 'Q'
      */
    quarter?: string;

    /**
      * An array of strings giving abbreviated names of the months, starting with January.
      * @default ['Jan', 'Feb', ...etc]
      */
    shortMonths?: string[];
  }

  /** Options to control the appearance and behavior of the histogram bars. */
  interface StyleOptions {
    /**
      * The color of the histogram bars or smooth area line.
      * @default 'light gray'
      */
    color?: string;

    /**
      * The color of the histogram bars when they are hovered over. Only available in histogram mode.
      * @default 'gray'
      */
    hoverColor?: string;

    /**
      * The color of histogram bars which contain highlighted times. Only available in histogram mode.
      * @default 'light red'
      */
    highlightColor?: string;

    /**
      * The color of the highlighted histogram bars when they are hovered over. Only available in histogram mode.
      * @default 'red'
      */
    highlightHoverColor?: string;
  }

  /** Options to control the allowed zoom extents. */
  interface ZoomOptions {
    /**
      * Sets the maximum zoom level (i.e., the smallest scale that the Time Bar will zoom in to).
      * Note that this sets the smallest allowed scale, although the smallest scale actually realized
      * may be larger.
      */
    max?: ZoomExtent;

    /**
      * Sets the minimum zoom level (i.e., the largest scale that the Time Bar will zoom out to).
      * Note that this value should be larger than that set in the `max` object, and if
      * left unset, ReGraph calculates the range between the data's earliest and latest times and
      * multiplies it by two.
      */
    min?: ZoomExtent;
  }

  interface ZoomExtent {
    /** The number of the specified units. */
    value?: number;

    /** The unit of the zoom. */
    unit?: 'year' | 'month' | 'week' | 'day' | 'hour' | 'min' | 'sec';
  }

  /** Options to control the appearance and behavior of the scale section. */
  interface ScaleOptions {
    /**
      * The color of the time scale section that is hovered over.
      * @default 'light gray'
      */
    hoverColor?: string;

    /**
      * Whether the major time scale (the lower scale) is shown.
      * @default true
      */
    showMajor?: boolean;

    /**
      * Whether the minor time scale (the higher scale) is shown.
      * @default true
      */
    showMinor?: boolean;
  }

  /** Options to control the appearance and behavior of the draggable sliders at the edges of the Time Bar. */
  interface SliderOptions {
    /**
      * The color to set the sliders. The default is white with an opacity of 0.6.
      */
    color?: string;

    /**
      * The color to set the bars at the inner edge of the sliders.
      * @default 'gray'
      */
    lineColor?: string;

    /**
      * Specifies slider behavior after a drag. Set to 'none' to hide the sliders.
      * @default 'fixed'
      */
    type?: 'fixed' | 'free' | 'none';
  }

  interface StackStyle {
    /**
      * Color of the stacked bar.
      */
    color: string;

    /**
      * The color applied to the stack when the bar is in a hover state. If this value is not specified, ReGraph will calculate a hover color based on the value you supplied for color.
      */
    hoverColor?: string;
  }

  interface StackOptions {
    /**
      * Splits histogram stacks by this value on an item's `data` property.
      * Items which don't have a matching property will be grouped into an 'other' stack.
      * @example
      *   const items = {
      *     a: { times: [Date.now()], data: { country: 'us' } },
      *     b: { times: [Date.now()], data: { country: 'uk' } },
      *   };
      *   const stackOpts = { stack: { by: 'country' }};
      *   return <TimeBar items={items} options={stackOpts} />
      */
    by: string;

    /**
      * A dictionary of styles, where each property corresponds to a value for the `by` property,
      * and its value contains a definition of the styles to be applied to it.
      *
      * Stacks are stacked vertically upwards following the order of the styles defined in this object.
      * The default time bar styling is used for the 'other' stack, containing items with no matching `by` value.
      * @example
      *   const items = {
      *    a: { times: [Date.now()], data: { country: 'us' } },
      *    b: { times: [Date.now()], data: { country: 'uk' } },
      *   };
      *   const stackOpts = {
      *     stack: {
      *       by: 'country',
      *       styles: {
      *         us: { color: 'maroon', hoverColor: 'red' } },
      *         uk: { color: 'navy', hoverColor: 'blue' } },
      *       }
      *     }
      *   };
      *   return <TimeBar items={items} options={stackOpts} />
      */
    styles?: Index<StackStyle>;
  }

  /** Options to control the labels on the scale section. */
  interface LabelsOptions {
    /**
      * The color to set the font of the Time Bar.
      * @default 'gray'
      */
    color?: string;

    /**
      * The default font family to use, such as 'arial' or 'helvetica'.
      * If the font isn't supported by the browser, or if none is set, 'sans-serif' is used.
      * @default 'sans-serif'
      */
    fontFamily?: string;

    /**
      * The font size to use. There is no size limit, but most fonts look better if you use a value between 7 and 13.
      * @default 12
      */
    fontSize?: number;
  }

  /** Defines the available options on the Time Bar's options prop. */
  interface Options {
    /**
      * The color to set the background of the Time Bar.
      * @default 'white'
      */
    backgroundColor?: string;

    /**
      * Options controlling animation of height changes for histogram bars and selection lines.
      */
    heightChange?: AnimationOptions;

    /**
      * Controls the appearance of histogram bars and smooth areas.
      */
    style?: StyleOptions;

    /**
      * Options to control the appearance of labels on the Time Bar (used in the scales).
      */
    labels?: LabelsOptions;

    /**
      * Specifies how dates and times are displayed.
      */
    locale?: LocaleOptions;

    /**
      * The speed that the Time Bar moves at when playing, in pixels per second.
      * May be negative to animate backwards.
      * @default 60
      */
    playSpeed?: number;

    /**
      * Options for the minor and major time scales.
      */
    scale?: ScaleOptions;

    /** Options to control the appearance of the sliders to the left and right of the histogram bars. */
    sliders?: SliderOptions;

    /** Specifies how to create stacked bars. */
    stack?: StackOptions;

    /** Specifies the bounds within which the user can zoom. */
    zoom?: ZoomOptions;
  }

  /** The object published to the onChange event handler whenever the Time Bar changes. */
  interface ChangeEvent {
    /** Shows which items are currently in the visible range. */
    items?: Items;

    /** The current visible time-range. */
    range?: TimeRange;

    /** Indicates if the play state has changed. */
    play?: boolean;
  }

  /** Options for the imperative view methods. */
  interface ViewChangeOptions {
    /**
      * The time the animation should take, in milliseconds.
      * @default 200
      */
    time: number;
  }
}

export interface FitToOptions {
  /** The width of the exported image. May be reduced to maintain the aspect ratio.
    * @default The current Chart width
    */
  width?: number;
  /** The height of the exported image. May be reduced to maintain the aspect ratio.
    * @default The current Chart height */
  height?: number;
}

export interface CoreExportOptions {
  /** The file format to export to.
    * @default 'png'
    */
  type: string;
  /** Scales the result to fit to the specified size while keeping the aspect ratio.
    * For PDF this can also be set to 'page' to fit and fill the page space.
    * Browsers set varying limits on max size, and will error if exceeded.
    * Note that this option is not supported in map mode. */
  fitTo?: FitToOptions | 'page';
  /** Specifies whether the exported result contains only the current view or the full chart.
    * @default 'view'
    */
  extents?: 'view' | 'chart';
}

export interface FontResource {
  /** URL or base64 encoding of the .woff or .ttf font file for this style. */
  src: string;
  /** Optional parameter for PDF export to specify the weight of the font encoded by this font file. */
  weight?: 'regular' | 'bold';
}

export interface FontExportOptions {
  /** A dictionary to manually define font resources, indexed by font names.
    * Only required when automatic font loading fails, giving a 'Font not found' warning.
    *
    * @example
    * fonts: {
    *   'Font Awesome 5 Free Regular': {
    *      src: '../fonts/fontAwesome5/fa-regular-400.woff'
    *   },
    *   Muli: {
    *      src: '../fonts/Muli/Muli-Regular.ttf'
    *   }
    * }
    */
  fonts?: Record<string, FontResource | FontResource[]>;
}

export interface PNGExportOptions extends CoreExportOptions {
  type: 'png';
}

export interface JPEGExportOptions extends CoreExportOptions {
  type: 'jpeg';
}

export interface SVGExportOptions extends CoreExportOptions, FontExportOptions {
  type: 'svg';
}

interface PdfKitDocumentOptions extends Record<string, any> {
  /** The size of the page.
    * @default 'letter'
    */
  size?: string;
  /** A single value in DPI for all page edge margins. Overrides the `margins` option.
    * @default 72
    */
  margin?: number;
  /** The margins in DPI to be applied to page edges.
    */
  margins?: { top: number; left: number; bottom: number; right: number };
  /** The page orientation.
    * @default 'portrait'
    */
  layout?: 'portrait' | 'landscape';
}

type PdfKitDocument = any;
export interface PDFExportOptions extends CoreExportOptions, FontExportOptions {
  type: 'pdf';
  /** The heading to be shown above the chart image in the exported PDF. This option is ignored when a custom PDFKit `doc` is passed. */
  heading?: string;
  /** Options to customize the PDFDocument object created by PDFKit, or to pass your own PDFDocument. */
  doc?: PdfKitDocument | PdfKitDocumentOptions;
}

/** Options for the export instance method. */
export type ExportOptions =
  | JPEGExportOptions
  | PDFExportOptions
  | PNGExportOptions
  | SVGExportOptions;

interface ExportWarningBase {
  /** The type of warning. */
  type: string;
  /** The warning message. */
  msg: string;
}
interface ExportFontWarning extends ExportWarningBase, Partial<FontResource> {
  type: 'font';
  fontFamily: string;
}

interface ExportDependencyWarning extends ExportWarningBase {
  type: 'dependency';
  /** The name of the dependency the warning relates to. */
  name: string;
}

interface ExportImageWarning extends ExportWarningBase {
  type: 'image';
  /** URL of the image the warning relates to. */
  src: string;
}

interface ExportSizeWarning extends ExportWarningBase {
  type: 'size';
}

export type ExportWarning =
  | ExportFontWarning
  | ExportDependencyWarning
  | ExportImageWarning
  | ExportSizeWarning;

export interface DownloadOptions {
  /** Whether the browser should release the reference to the image after the download.
    * Set to false to keep the image accessible.
    * @default true
    */
  revokeObjectURL?: boolean;
}

export type DownloadExport = (name: string, options?: DownloadOptions) => void;

/** The value returned by the export instance method. */
export interface ExportResult {
  /** The url containing the blob url for the exported image. */
  url?: string;
  /** Any array of warnings generated by the export. */
  warnings?: ExportWarning[];
  /** A function that downloads the image when called.
    * Cannot be used when a custom PDFKit `doc` is passed. Create a custom function to download the PDF.
    * @param name The name of the downloaded file.
    * @param options Options for handling url after downloading.
    */
  download: DownloadExport;
}

/**
  * Utility interface to define an index (or dictionary) object whose values match a specific type.
  */
export interface Index<T> {
  [id: string]: T;
}

export type CompassPoint = 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w' | 'nw';

/** Abstract definition of a Chart or Time Bar item. */
export interface Item<T = any> {
  /**
    * Fades the item into the background. Can be used in the `setStyle` function passed to `onItemInteraction` to foreground items.
    * @default false
    */
  fade?: boolean;

  /**
    * The fill color. Defaults to gray for nodes and links.
    */
  color?: string;

  /**
    * Used to store custom data on an item. Used by graph functions, layouts and combos.
    */
  data?: T;

  /**
    * Associates timestamps with the item. A timestamp can represent a single moment or a period of
    * time.
    * @example <TimeBar items={{
    *     node1: {
    *       times: [{ time: new Date(2019, 4, 1) }],
    *     },
    *     node2: {
    *       times: [
    *         {
    *           time: {
    *             start: 1554713715658,
    *             end: 1558624743356,
    *           },
    *         },
    *       ],
    *     },
    *   }}
    * />
    */
  times?: Array<Time | number>;

  /**
    * An array of objects describing the glyphs shown on the item.
    */
  glyphs?: Glyph[];
}

/** Definition of a Chart Node (can also be consumed by the Time Bar) */
export interface Node<T = any> extends Item<T> {
  /**
    * Crops an image to a cutout circle. Affected by cross-origin restrictions and does not apply to font icons.
    * @default false
    */
  cutout?: boolean;

  /**
    * Defines a border around a node. Set a `color` property to make a border appear.
    * @default No border
    * @example <Chart items={{
    *     node1: {
    *       border: {
    *          color: 'maroon'
    *       }
    *     }
    *   }}
    * />
    */
  border?: StyledBorder;

  /**
    * An object describing a 'donut' border of segmented sections around the node.
    * Doesn't apply to nodes with `shape` set to 'box'.
    * If both `donut` and `border` are set then `donut` takes precedence.
    */
  donut?: Donut;

  /**
    * Defines a label for a node.
    */
  label?: NodeLabel | NodeLabelContainer | NodeLabelContainer[];

  /**
    * Scales the node size by an enlargement factor. Does not apply to nodes with `width` and `height` set in the `shape` property.
    * @default 1
    */
  size?: number;

  /**
    * The font icon used on the node.
    * @example <Chart items={{
    *    node1: {
    *      fontIcon: {
    *        text: 'fa-user',   // or '\u{f007}'
    *        fontFamily: 'Font Awesome 5 Free'
    *      }
    *    }
    *    }}
    * />
    */
  fontIcon?: FontIcon;

  /**
    * Adds halos to the node. Halos are concentric circles which are drawn around nodes. A node can have up to ten halos.
    */
  halos?: Halo[];

  /**
    * An object describing the position of the node on the map when in map mode.
    */
  coordinates?: Location;

  /**
    * The node's shape. Can also be set to an object with parameters in world units to set a rectangular node.
    * @default 'circle'
    */
  shape?:
    | 'box'
    | 'circle'
    | { height: number | 'auto'; width: number | 'auto'; minHeight?: number; minWidth?: number };

  /**
    * The URL to the node image.
    */
  image?: string;
}

export interface LinkStyle<T> extends Item<T> {
  /**
    * Sets a flow animation on the link. Overrides the `lineStyle` property.
    * @default { velocity: 2}
    */
  flow?: boolean | LinkFlowOptions;

  /**
    * Places a label at the middle of the link.
    */
  label?: Label;

  /**
    * The style of the link line.
    * @default 'solid'
    */
  lineStyle?: 'solid' | 'dashed' | 'dotted';

  /**
    * The width of the link line. Arrowheads, if present, will enlarge to match the width.
    * @default 1
    */
  width?: number;

  /**
    * Defines the link at the id1 end.
    */
  end1?: LinkEnd;

  /**
    * Defines the link at the id2 end.
    */
  end2?: LinkEnd;
}

export interface LinkFlowOptions {
  /**
    * Sets the velocity of the flow along the link.
    * Positive values flow from `id1` to `id2`, and negative from `id2` to `id1`.
    * Should be in the range -10 to 10.
    * @default 2
    */
  velocity: number;
}

/** Definition of a Chart link (can also be consumed by the Time Bar). */
export interface Link<T = any> extends LinkStyle<T> {
  /**
    * The identity of the node at one end of the link.
    */
  id1: string;

  /**
    * The identity of the node at the other end of the link. This may be the same as id1 to create a "self link".
    */
  id2: string;
}

export interface LinkEnd {
  /**
    * Draws an arrowhead at the end of the link.
    * @default false
    */
  arrow?: boolean;

  /**
    * The distance the link should back-off from the connected node, as a ratio of the total length of the link line. Value in the range 0 to 1.
    * @default 0
    */
  backOff?: number;

  /**
    * Sets the color of this end of the link. May be different to the other end, in which case the link will draw a gradient.
    */
  color?: string;

  /**
    * An array of objects describing the glyphs shown at the end of the link.
    */
  glyphs?: Glyph[];

  /**
    * Specifies the label at the end of the link.
    */
  label?: Label;
}

export interface Glyph {
  /**
    * Applies a blink animation to the glyph.
    * @default false
    */
  blink?: boolean;

  /**
    * Applies a border to the glyph.
    * @default No border
    */
  border?: GlyphBorder;

  /**
    * The color of the glyph fill. If color is specified then the image will be shown inside the glyph. If no color is specified then the image replaces the glyph circle and no label is shown.
    * @default 'rgb(60,60,60)' (if image is undefined)
    */
  color?: string;

  /**
    * Sets a font icon on the glyph.
    */
  fontIcon?: FontIcon;

  /**
    * Sets an enlargement factor on the glyph.
    * @default 1
    */
  size?: number;

  /**
    * Specifies the label of the glyph.
    * If a label is specified then it takes precedence over the image.
    */
  label?: GlyphLabel;

  /**
    * The glyph position relative to the node or combo. Values are integer angles measured
    * clockwise from north (in the range 0-359).
    * Multiple glyphs on the same node or combo must be positioned using the same positioning property; either `angle` or `position`.
    */
  angle?: number;

  /**
    * The position of the glyph relative to the node or combo. Values are compass points.
    * Multiple glyphs on the same node or combo must be positioned using the same positioning property; either `angle` or `position`.
    * @default 'ne'
    */
  position?: CompassPoint;

  /**
    * Sets the distance from the center of the node or closed combo at which the glyph is drawn.
    * Only available when the glyph's `angle` is defined - ignored when `position` is set.
    * If specified, link ends will no longer avoid the glyph.
    */
  radius?: number;

  /**
    * The URL of the image to use for the glyph. The image can be any size, but 64X64 should be adequate.
    */
  image?: string;
}

export interface GlyphLabel {
  /**
    * Whether the label should be displayed in bold font.
    * @default false
    */
  bold?: boolean;

  /**
    * The color of the label font.
    * @default 'white'
    */
  color?: string;

  /**
    * The font family to use for the label. Defaults to the `fontFamily` property of the `labels` options in the chart's `options` prop.
    */
  fontFamily?: string;

  /**
    * The label text.
    */
  text?: string;
}

export interface LabelBase extends GlyphLabel {
  /**
    * The label background color.
    * @default 'rgba(255,255,255,0.6)'
    */
  backgroundColor?: string;
}

export interface Label extends LabelBase {
  /**
    * The font size (px) of the label.
    * @default 14
    */
  fontSize?: number;
}

export interface NodeLabel extends Label {
  /**
    * **DEPRECATED** Vertically centers the label text against the node. If false, the label will appear beneath the node. Deprecated since v4.0. Use the `position` property instead.
    * @default true
    */
  center?: boolean;
}

type HorizontalAlignment = 'left' | 'center' | 'right';
type VerticalAlignment = 'top' | 'middle' | 'bottom';

interface NodeLabelContainerPosition {
  horizontal?: number | HorizontalAlignment;
  vertical?: number | VerticalAlignment | 'initial' | 'inherit';
}

interface NodeLabelContainerTextAlignment {
  horizontal?: HorizontalAlignment;
  vertical?: VerticalAlignment;
}

type BoxSpacing = Record<'top' | 'right' | 'bottom' | 'left', number>;

export interface NodeLabelContainer extends LabelBase {
  /**
    * The border around the label.
    * @default No border
    */
  border?: BorderWithBorderRadius;
  /**
    * The space between the label and the next label or the parent node. Use a number for equal margin on all sides, a string (separated by spaces) containing two, three or four numbers,
    * an array (separated by commas) containing two, three or four numbers, or an object setting values for individual properties such as `top` or `right`.
    */
  margin?: number | [number, number?, number?, number?] | string | Partial<BoxSpacing>;
  /**
    * The minimum height of the label container. It will increase to fit the content if necessary. When set to 'stretch', it fills the whole height of the parent node.
    */
  minHeight?: number | 'stretch';
  /**
    * The minimum width of the label container. It will increase to fit the content if necessary. When set to 'stretch', it fills the whole width of the parent node. Set to a number if `textWrap` is set to 'normal' to increase the minimum text width before a line break.
    */
  minWidth?: number | 'stretch';
  /** The maximum height of the label container. Use this option when `fontSize` is set to 'auto' to set the maximum height of the text. */
  maxHeight?: number;
  /** The maximum width of the label container. It defaults to the parent node width. Set this option when `textWrap` is set to 'normal' to reduce the maximum text width before a line break, or when fontSize is set to 'auto' to set the maximum text width.
    */
  maxWidth?: number;
  /**
    * The space between the label border and the content inside the label. Use a number for equal padding on all sides, a string (separated by spaces) containing two, three or four numbers,
    * an array (separated by commas) containing two, three or four numbers, or an object setting values for individual properties such as `top` or `right`.
    * @default '2 2 0 2'
    */
  padding?: number | [number, number?, number?, number?] | string | Partial<BoxSpacing>;
  /**
    * The position of the label's top left corner relative to the top left node corner. Can either be a compass point string ( 'n', 'ne' etc.) to place the label outside the node, or an object with `horizontal` and/or `vertical` properties to place the label inside the node.
    *
    * Default position for nodes and closed combos is in the middle and centre of the node.
    * Default position for open combos is outside and below the combo.
    * @default { horizontal: 'center', vertical: 'middle' }
    */
  position?: NodeLabelContainerPosition | CompassPoint;
  /**
    * The alignment of the content inside the label. Applies when labels are not sized automatically to their content due to `minHeight` and/or `minWidth` options set.

    * @default { horizontal: 'center', vertical: 'middle' }
    */
  textAlignment?: NodeLabelContainerTextAlignment;
  /**
    * Strategy for text wrapping inside the label. The default is 'initial' which means that no text wrapping is applied.
    * Set the option to 'normal' to wrap the label on whitespaces created by the space bar.
    * The line breaks are controlled by the `minWidth` and `maxWidth` properties.
    * Note that you can also force a line break using the '\n' or '\r' characters.
    * @default 'initial'
    */
  textWrap?: 'initial' | 'normal';
  /**
    * The label font icon. If both `fontIcon` and `text` are set, `text` is ignored.
    */
  fontIcon?: FontIcon;
  /**
    * The font size (px) of the label. Set to 'auto' to size the font automatically depending on the node size.
    * @default 14
    */
  fontSize?: number | 'auto';
}

export interface GlyphBorder {
  /**
    * The border color.
    */
  color?: string;
}

export interface Border {
  /**
    * The border color.
    */
  color?: string;
  /**
    * The width of the border.
    * @default 4
    */
  width?: number;
  /**
    * The radius of border corners.
    * Use a number for equal radius for all corners, a string (separated by spaces) containing two, three or four numbers,
    * an array (separated by commas) containing two, three or four numbers, or an object setting values for individual properties such as `topLeft` or `bottomRight`.
    * @default 0
    */
  radius?: BorderRadius;
}

export interface DonutBorder {
  /**
    * The border color.
    * @default 'white'
    */
  color?: string;
  /**
    * The width of the border.
    * @default 2
    */
  width?: number;
}

export type BorderRadius =
  | number
  | string
  | [number, number?, number?, number?]
  | { topLeft?: number; topRight?: number; bottomRight?: number; bottomLeft?: number };

export interface BorderWithBorderRadius extends Border {
  /**
    * The radius of border corners.
    * Use a number for equal radius for all corners, a string (separated by spaces) containing two, three or four numbers,
    * an array (separated by commas) containing two, three or four numbers, or an object setting values for individual properties such as `topLeft` or `bottomRight`.
    * @default 0
    */
  radius?: BorderRadius;
}

export interface StyledBorder extends BorderWithBorderRadius {
  /**
    * The style of the border line.
    * @default 'solid'
    */
  lineStyle?: 'solid' | 'dashed';
}

export interface Location {
  /**
    * The latitude in degrees that this node is positioned at when a map is shown.
    */
  lat: number;

  /**
    * The longitude in degrees that this node is positioned at when a map is shown.
    */
  lng: number;
}

export interface FontIcon {
  /**
    * The color of the font icon fill.
    * @default 'black'
    */
  color?: string;

  /**
    * The font family to use for the font icon. Defaults to the `iconFontFamily` option in the chart's `options` prop.
    */
  fontFamily?: string;

  /** The text of the font icon to show. You can pass a CSS class name here which will be converted to a unicode character, or you can pass an escaped Unicode code point, e.g. '\u{f007}'. */
  text: string | number;
}

export interface Halo {
  /** The color of the halo. */
  color: string;

  /** The radius of the halo. */
  radius: number;

  /** The width of the halo. */
  width: number;
}

export interface Donut {
  /**
    * Defines the border between segments.
    */
  border?: DonutBorder;

  /**
    * Defines the segments of the donut.
    */
  segments: DonutSegment[];

  /**
    * The width of the donut segments (excluding the border).
    * @default 10
    */
  width?: number;
}

export interface DonutSegment {
  /**
    * The color of this segment.
    */
  color?: string;

  /**
    * The size of this segment. Values should be positive. Segments are positioned clockwise around the node starting at the top.
    */
  size: number;
}

export interface TimePeriodOpenEnd {
  /** The timestamp for the start of the time period, either a Date object or a millisecond number. */
  start: Date | number;
}

export interface TimePeriodOpenStart {
  /** The timestamp for the end of the time period, either a Date object or a millisecond number. */
  end: Date | number;
}

export interface TimePeriodFixed extends TimePeriodOpenEnd, TimePeriodOpenStart {}

export type TimePeriod = TimePeriodOpenEnd | TimePeriodOpenStart | TimePeriodFixed;

export interface Time {
  /**
    * The value associated with a timestamp (for example, the amount of a transaction or the duration of a call).
    * @default 1
    */
  value?: number;

  /**
    * Set the time as a specific moment as a Date or a time in milliseconds. To specify a time
    * interval, set the time as an object with `start` and `end`. If only
    * `start` or `end` is provided, the interval is treated as an open
    * interval.
    */
  time?: Date | number | TimePeriod;
}

export interface SubItem {
  /**
    * The type of the sub-item.
    */
  type: 'label' | 'arrowhead' | 'donut' | 'glyph' | 'halo';

  /**
    * The index of the sub-item in its parenting property. This property will only be set if the `type`
    * is either 'label', 'donut', 'glyph' or 'halo'.
    *
    *
    * @example function onClick({id, x, y, button, subItem}) {
    *   if (subItem && subItem.type === 'glyph') {
    *      console.log(subItem.index); // 0 for the first glyph, 1 for the second, etc
    *    }
    * }
    */
  index?: string | number;

  /**
    * The end of the link the sub-item is attached to. This property will only be set if the type is
    * either `arrowhead`, `glyph` or `label`.
    */
  linkEnd?: 'end1' | 'end2';
}

export interface ModifierKeys {
  /** A dictionary detailing which modifier keys were pressed when the event occurred. */
  modifierKeys: {
    /** If an alt key was held down when the event occurred. */
    alt: boolean;
    /** If a control key was held down when the event occurred. */
    ctrl: boolean;
    /** If a consistent control key (ctrl key, cmd key on MacOS) was held down when the event occurred. */
    consistentCtrl: boolean;
    /** If the meta key was held down when the event occurred. */
    meta: boolean;
    /** If a shift key was held down when the event occurred. */
    shift: boolean;
  };
}

export interface PreventDefault {
  /** A read-only value indicating if the default action was prevented. */
  readonly defaultPrevented: boolean;
  /** Call to prevent the default action of the event. */
  preventDefault: () => void;
}

export interface BasePointerEvent extends ModifierKeys {
  /** The index of the button used. */
  button: number;
  /** The type of pointing device. */
  pointerType: string;
  /** The unique identifier of the pointer. */
  pointerId: number;
  /** The x location of the pointer in view coordinates. */
  x: number;
  /** The y location of the pointer in view coordinates. */
  y: number;
}

export interface BaseWheelEvent extends PreventDefault, ModifierKeys {
  /** The unit of measurement for the delta value. */
  deltaMode: number;
  /** The number of units that the wheel scrolled in the x direction. */
  deltaX: number;
  /** The number of units that the wheel scrolled in the y direction. */
  deltaY: number;
  /** The x location of the pointer in view coordinates. */
  x: number;
  /** The y location of the pointer in view coordinates. */
  y: number;
}

