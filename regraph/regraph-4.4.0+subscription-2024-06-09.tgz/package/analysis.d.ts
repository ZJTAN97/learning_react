 /**
 * Type definitions for ReGraph analysis functions.
 * 
 * Copyright © 2011-2023 Cambridge Intelligence Limited.
 * All rights reserved.
 */

import { Index, Items } from './index';

type Values = Index<number>;

/**
 * Calculates the betweenness centrality of all nodes in the graph.
 * @param items The items to analyze.
 * @param options Various options which define whether the graph is directed, the result normalized and values associated with the links.
 * @returns Returns a Promise which resolves to a dictionary whose properties are the ids of the nodes in the graph. The values are the betweenness values. */
export function betweenness(items: Items, options?: BetweennessOptions): Promise<Values>;

interface BetweennessOptions {
  /**
   * Whether the betweenness computation should consider the direction of links.
   * @default false
   */
  directed?: boolean;
  /** Normalizes the results to ensure that returned values are between 0 and 1.
   * ‘chart’ normalizes the scores of all nodes on the chart by dividing by a single value.
   * ‘component’ considers each unconnected part of a chart as a separate graph, dividing all
   * connected nodes by the same value, but other components by a different value.
   * @default 'component'
   */
  normalization?: 'unnormalized' | 'chart' | 'component';
  /**
   * The name of the custom property which defines each link's weighting value. Custom properties mean properties set on the `data` property of the links. */
  value?: string;
  /**
   * Specifies if the path length of links are the reciprocal of their value, i.e. ( 1 / value ).
   * @default false
   */
  weights?: boolean;
}

/** Calculates the closeness centrality of all nodes in the graph.
 * @param items The items to analyze.
 * @param options Options which define whether the graph is directed, the result normalized and values associated with the links.
 * @returns Returns a Promise which resolves to a dictionary whose properties are the ids of the nodes in the graph. The values are the closeness values. */
export function closeness(items: Items, options?: ClosenessOptions): Promise<Values>;

/** Groups nodes in the graph into a set of clusters, and then returns an object describing them.
 * @param items The items to analyze.
 * @param options Options which special rules for the clusters calculation.
 * @returns Returns a Promise which resolves to an array of dictionaries, one entry for each cluster. The values of each dictionary are the items in that cluster. */
export function clusters(items: Items, options?: ClustersOptions): Promise<Items[]>;

/** Returns the separate 'connected components' of the graph.
 * @param items The items to analyze.
 * @returns Returns a Promise which resolves to an array of dictionaries, one entry for each component. The values of each dictionary are the items in that component. */
export function components(items: Items): Promise<Items[]>;

/** Calculates the degrees (number of links) of all nodes in the graph.
 * @param items The items to analyze.
 * @param options Options which define the direction and values associated with the links.
 * @returns Returns a Promise which resolves to an object whose properties are the ids of the nodes, the values of which are the degree values. */
export function degrees(items: Items, options?: DegreesOptions): Promise<Values>;

/** Calculates the distances of all nodes from the node specified. The distance is the number of edges in a shortest path.
 * @param items The items to analyze.
 * @param id The id of the node to start from.
 * @param options Options for the direction and values associated with the paths.
 * @returns Returns a Promise which resolves to a dictionary object, where the properties are the ids of the nodes and the values are the distances. */
export function distances(items: Items, id: string, options?: DistancesOptions): Promise<Values>;

/** Computes the eigenvector centrality of each node.
 * @param items The items to analyze.
 * @param options Options which define special rules for the eigencentrality computation.
 * @returns Returns a Promise which resolves to a dictionary object, where the properties are the ids of the nodes and the values are the eigenvector centralities. */
export function eigenCentrality(items: Items, options?: EigenCentralityOptions): Promise<Values>;

/** Calculates subgraphs of the graph where each node has a degree at least k. It works by successively removing nodes of degree less than k until no further nodes can be removed.
 * @param items The items to analyze.
 * @returns Returns a Promise which resolves to an object which describes the kCores found. */
export function kCores(items: Items): Promise<KCoresResult>;

/** Calculates the list of neighboring (i.e. linked) items to the ids supplied.
 * @param items The items to analyze.
 * @param id The items whose neighbors should be found. Can be either a string id, an array of string ids, or an object of items (indexed by id).
 * @param options Options which define special rules for items iteration.
 * @returns Returns a Promise which resolves to a dictionary of neighboring items. */
export function neighbors(
  items: Items,
  id?: string | string[] | Items,
  options?: NeighborsOptions,
): Promise<Items>;

/** Computes the Page Rank of each node.
 * @param items The items to analyze.
 * @param options Options which define special rules for the Page Rank computation.
 * @returns Returns a Promise which resolves to a dictionary object, where the properties are the ids of the nodes and the values are the Page Rank scores. */
export function pageRank(items: Items, options?: PageRankOptions): Promise<Values>;

/** Calculates all the shortest paths between the nodes specified.
 * @param items The items to analyze.
 * @param id1 The id of the starting node on the path.
 * @param id2 The id of the ending node on the path.
 * @param options Various options for the direction and values associated with the paths.
 * @returns Returns a Promise which resolves to an object which describes the path structure. */
export function shortestPaths(
  items: Items,
  id1?: string,
  id2?: string,
  options?: ShortestPathsOptions,
): Promise<ShortestPathsResult>;

interface ClosenessOptions {
  /** Specifies whether to take link direction into account. 'from' only includes links in the direction of arrows, 'to' only includes links against the direction of arrows, and 'any' includes any link regardless of arrows. Note that to use 'from' or 'to', your graph must have arrows on links.
   * @default 'any'
   */
  direction?: 'from' | 'to' | 'any';
  /** Normalizes the results to ensure that returned values are between 0 and 1.
   * ‘chart’ normalizes the scores of all nodes on the chart by dividing by a single value.
   * ‘component’ considers each unconnected part of a chart as a separate graph, dividing all
   * connected nodes by the same value, but other components by a different value.
   * @default 'component'
   */
  normalization?: 'chart' | 'component';
  /** The name of the custom property which defines each link's weighting value. Custom properties mean properties set on the `data` property of the links. */
  value?: string;
  /** Specifies if the path length of links are the reciprocal of their value, i.e. ( 1 / value ).
   * @default false
   */
  weights?: boolean;
}

interface ClustersOptions {
  /** The name of a custom property which defines each link's weighting value. Custom properties mean properties set on the `data` property of the links. Higher valued links tend to cluster their nodes more closely. */
  value?: string;
  /** A number from 0 to 10 that affects cluster size. Higher values give smaller clusters, but more of them; lower values give larger clusters, but not as many.
   * @default 5
   */
  factor?: number;
  /** Set to true to see the same result every time you run a cluster, or false if you want to see different results.
   * @default true
   */
  consistent?: boolean;
}

interface DegreesOptions {
  /** Specifies whether to take link direction into account. 'from' counts only links with arrows pointing away from nodes (out-degree), 'to' counts only links with arrows pointing to nodes (in-degree), and 'any' counts all links regardless of whether they have arrows. Note that to use 'from' or 'to', your graph must have arrows on links.
   * @default 'any'
   */
  direction?: 'from' | 'to' | 'any';
  /** The name of the custom property which defines each link's weighting value.  Custom properties mean properties set on the `data` property of the links. */
  value?: string;
}

interface DistancesOptions {
  /** Specifies whether to take link direction into account. 'from' only includes links in the direction of arrows, 'to' only includes links against the direction of arrows, and 'any' includes any link regardless of arrows. Note that to use 'from' or 'to', your graph must have arrows on links.
   * @default 'any'
   */
  direction?: 'from' | 'to' | 'any';
  /** The name of the custom property which defines the distance value of a link.  Custom properties mean properties set on the `data` property of the links. */
  value?: string;
  /** Specifies if the path length of links are the reciprocal of their value, i.e. ( 1 / value ).
   * @default false
   */
  weights?: boolean;
}

interface EigenCentralityOptions {
  /** The name of the custom property which defines each link's weighting value.  Custom properties mean properties set on the `data` property of the links. If not set, all links have value 1. */
  value?: string;
}

interface KCoresResult {
  /** The maximum k in the graph. */
  maximumK?: number;
  /** A dictionary of all nodes, each one with its k value. */
  values?: Values;
}

interface NeighborsOptions {
  /** Specifies whether to take link direction into account. 'from' only finds neighbors in the direction of arrows, 'to' only finds neighbors against the direction of arrows, and 'any' finds neighbors on any link regardless of arrows. Note that to use 'from' or 'to', your graph must have arrows on links.
   * @default 'any'
   */
  direction?: 'from' | 'to' | 'any';
  /** Defines how far away neighbors can be from the passed ids.
   * @default 1
   */
  hops?: number;
}

interface PageRankOptions {
  /** The name of the custom property which defines each link's weighting value.  Custom properties mean properties set on the `data` property of the links. If not set, all links have value 1. */
  value?: string;
  /** Whether the Page Rank computation should consider the direction of links.
   * @default true
   */
  directed?: boolean;
}

interface ShortestPathsResult {
  /** One of the shortest paths found - returned an array of alternating node and link ids. Includes the start and end nodes. */
  onePath: string[];
  /** An array of ids describing the same path as `onePath`, but containing nodes only. Includes the start and end nodes. */
  one: string[];
  /** A dictionary whose properties are the ids of items on the shortest paths. The values are the item definitions. */
  items: Items;
  /** The length of the shortest path - more precisely the combined link value of the path. */
  distance: number;
}

interface ShortestPathsOptions {
  /** Specifies whether to take link direction into account. 'from' only traverses links in the direction of arrows, 'to' only traverses links against the direction of arrows, and 'any' can traverse any link regardless of arrows. Note that to use 'from' or 'to', your graph must have arrows on links.
   * @default 'any'
   */
  direction?: 'from' | 'to' | 'any';
  /** The name of the custom property which defines each link's weighting value.  Custom properties mean properties set on the `data` property of the links. */
  value?: string;
  /** Specifies if the path length of links are the reciprocal of their value, i.e. ( 1 / value ).
   * @default false
   */
  weights?: boolean;
}
