/**
 * ReGraph 4.4.0
 * Licensed to Centre for Strategic Infocomm Technologies for Network Mapping Application expires 09 June 2024
 * 
 * Copyright © 2011-2024 Cambridge Intelligence Limited.
 * All rights reserved.
 */"use strict";var t=require("pdfkit/js/pdfkit.standalone"),e=require("svg-to-pdfkit"),o=require("blob-stream");function d(t){return t&&"object"==typeof t&&"default"in t?t:{default:t}}var f=d(t),i=d(e),u=d(o);"object"==typeof window&&null!=window&&(void 0!==typeof f.default&&(window.PDFDocument=f.default),void 0!==typeof u.default&&(window.blobStream=u.default),void 0!==typeof i.default&&(window.SVGtoPDF=i.default));
